%% Assignment 1
